import { IsString, IsBoolean, Length, IsNumber } from 'class-validator';
import { BaseDTO } from './base.dto';
import { EquipoDTO } from './equipo.dto';
import { JugadorDTO } from './jugador.dto';

export class PlantillaDTO extends BaseDTO {
  @IsNumber()
  idequipo: number;
  equipo: EquipoDTO;

  @IsNumber()
  idjugador: number;
  jugador: JugadorDTO;

  @IsBoolean()
  fijo: boolean;

  @IsNumber()
  dorsal: number;
}