import { Controller } from '@nestjs/common';

@Controller('plantilla')
export class PlantillaController {}
