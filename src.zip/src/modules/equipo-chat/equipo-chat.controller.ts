import { Controller } from '@nestjs/common';

@Controller('equipo-chat')
export class EquipoChatController {}
